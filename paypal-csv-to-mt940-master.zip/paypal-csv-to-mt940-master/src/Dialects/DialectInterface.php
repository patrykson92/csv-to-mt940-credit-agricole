<?php
namespace Deargonaut\PaypalCsvToMt940\Dialects;

interface DialectInterface
{
    /**
     * Validate it self.
     * 
     * @throws \Exception
     * @return bool True on success and False on failure.
     */
    //public function validate() : bool;
}